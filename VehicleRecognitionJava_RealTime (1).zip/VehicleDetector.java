
import org.opencv.core.*;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.opencv.videoio.VideoCapture;
import org.opencv.videoio.Videoio;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

public class VehicleDetector {
    public void run() {
        CascadeClassifier vehicleCascade = new CascadeClassifier("resources/cars.xml");
        VideoCapture capture = new VideoCapture(0);

        if (!capture.isOpened()) {
            System.out.println("Cannot open webcam");
            return;
        }

        capture.set(Videoio.CAP_PROP_FRAME_WIDTH, 640);
        capture.set(Videoio.CAP_PROP_FRAME_HEIGHT, 480);

        Mat frame = new Mat();
        JFrame window = new JFrame("Vehicle Detection - Webcam");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel videoLabel = new JLabel();
        window.setContentPane(videoLabel);
        window.setSize(640, 480);
        window.setVisible(true);

        while (true) {
            if (!capture.read(frame)) {
                System.out.println("No frame captured");
                break;
            }

            Mat gray = new Mat();
            Imgproc.cvtColor(frame, gray, Imgproc.COLOR_BGR2GRAY);
            MatOfRect vehicles = new MatOfRect();
            vehicleCascade.detectMultiScale(gray, vehicles);

            for (Rect rect : vehicles.toArray()) {
                Imgproc.rectangle(frame, new Point(rect.x, rect.y),
                        new Point(rect.x + rect.width, rect.y + rect.height),
                        new Scalar(0, 255, 0), 2);
            }

            ImageIcon image = new ImageIcon(matToBufferedImage(frame));
            videoLabel.setIcon(image);
            videoLabel.repaint();

            if (!window.isVisible()) {
                break;
            }
        }

        capture.release();
    }

    private BufferedImage matToBufferedImage(Mat matrix) {
        int type = BufferedImage.TYPE_3BYTE_BGR;
        if (matrix.channels() == 1) {
            type = BufferedImage.TYPE_BYTE_GRAY;
        }

        int bufferSize = matrix.channels() * matrix.cols() * matrix.rows();
        byte[] buffer = new byte[bufferSize];
        matrix.get(0, 0, buffer);
        BufferedImage image = new BufferedImage(matrix.cols(), matrix.rows(), type);
        final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
        System.arraycopy(buffer, 0, targetPixels, 0, buffer.length);
        return image;
    }
}
