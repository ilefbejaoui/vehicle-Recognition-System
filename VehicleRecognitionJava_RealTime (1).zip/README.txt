Vehicle Recognition System in Java using OpenCV.
Add a sample image as 'car.jpg' and 'cars.xml' classifier in resources folder.
